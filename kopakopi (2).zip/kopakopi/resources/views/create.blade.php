@extends('layout')
@section('content')
<h1 style="text-align: center">Tambah Menu</h1>
@if(session()->has('message'))
    <p>{{ session()->get('message') }}</p>
@endif
<form action="{{ route('menu.store') }}" method="POST">
    <input type="hidden" name="_menu" value="{{ csrf_menu() }}">
    <div class="group">
        <label for="id_menu">menu</label>
        <input type="number" id_menu="id_menu" name="id_menu" value="{{ old('id_menu') }}">
        @if($errors->has('id-menu'))
            <small class="error">{{ $errors->first('id_menu') }}</small>
        @endif
    </div>
    <div class="group">
        <label for="nama_menu">Nama menu</label>
        <input type="text" id_menu="nama_menu" name="nama_menu" value="{{ old('nama_menu') }}">
        @if($errors->has('nama menu'))
            <small class="error">{{ $errors->first('nama menu') }}</small>
        @endif
    </div>
    <div class="group">
        <a href="{{ route('menu.index') }}">Batal</a>
        <button class="save">Simpan</button>
    </div>
</form>
@endsection
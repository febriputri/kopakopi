<table border="1">
    <tr>
        <th>Id Menu</th>
        <th>Nama Menu</th>
        <th>Jumlah Pesanan</th>
    </tr>
    @foreach($menu as $m)
    <tr>
        <td>{{$m->id_menu}}</td>
        <td>{{$m->nama_menu}}</td>
        <td>{{$m->jumlahpesanan}}</td>
        <td>
            <a href="/menu/{{$m->nama_menu}}/edit">Edit</a>
            <form action="" method="POST">
                @scrf
                @method('delete')
                <input type="submit" value="delete>
            </form>
        </td>
    </tr>
    @endforeach
</table>
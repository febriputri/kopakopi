<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;

    class MenuController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */

        public function index()
        {
            return response()->json([
                'Nama menu'=>'Vanilla Latte',
                'Jumlah pesanan' =>'3',
                'result'=>'Vanilla Latte',
            ]);
        }
    
    
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Http\Response
         */

        function add(Request $request)
        {
            $menu = new Menu;

            $menu -> id_menu=$request->id_menu;
            $menu -> nama_menu=$request->nama_menu;
            $menu -> jumlahpesanan=$request->jumlahpesanan;
            
            $result= $menu ->save();
            if($result)
        {
            return response()->json([
                'status'=>400,
                'error'=>'something went wrong'
            ]);
        }
        else{
            return response()->json([
                'status'=>200,
                'message'=>'Data Successfully saved'
            ]);
        }
}
    

        function delete(Request $request)
        {
            $menu= Menu::find($request);
            $result=$menu->delete();
            if($result)
            {
                return response()->json([
                    'status'=>400,
                    'error'=>'something went wrong'
                ]);
            }
            else{
                return response()->json([
                    'status'=>200,
                    'message'=>'Data Successfully deleted'
                ]);
            }
    }
        
        public function create()
        {
            //
            
            
        }
    
        /**
         * Store a newly created resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function store(Request $request)
        {
            //
    
        }
    
        /**
         * Display the specified resource.
         *
         * @param  \App\Models\Menu  $menu
         * @return \Illuminate\Http\Response
         */
        public function show(Menu $menu)
        {
            //
            $menu = Menu::where('menu',$menu)->firstOrFail();
            if (is_null($menu)){
                return $this->sendError('Menu tidak ditemukan');
            }
            return response()->json([
                "success"=> true,
                "message"=> "Data menu ditemukan.",
                "data"=>$menu,
            ]);
            
        }
    
        /**
         * Show the form for editing the specified resource.
         *
         * @param  \App\Models\Menu  $menu
         * @return \Illuminate\Http\Response
         */
        public function edit(Menu $menu)
        {
            //
        }
    
        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  \App\Models\Menu  $menu
         * @return \Illuminate\Http\Response
         */
        public function update(Request $request, Menu $menu)
        {
            $nama_menu=$request->nama_menu;
            $jumlahpesanan=$request->jumlahpesanan;

           $menu= Menu::find($request->nama_menu);
           $menu->nama_menu =$nama_menu;
           $menu->jumlahpesanan=$jumlahpesanan;
           $result= $menu->save();
           if($result)
           {
            return response()->json([
                'status'=>400,
                'error'=>'something went wrong'
            ]);
        }
        else{
            return response()->json([
                'status'=>200,
                'message'=>'Data Successfully updated'
            ]);
        }
}
        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Models\Menu  $menu
         * @return \Illuminate\Http\Response
         */
        public function destroy(Menu $menu)
        {
            $menu= menu::find($menu);
            $menu->delete();
    
            return 'data successfully deleted!';
    
        }
    }